<x-guest-layout>

    <main>
        <div class="affiliate-container">
            <p>CREATOR</p>
        </div>
    
        <div class="affiliate-content-container">
            <p>
                For an affordable yearly payment of ₦5,500
                start uploading and selling your own products on our platform forever as you also have people to sell it for you
            </p>
            <a class="visit-shop" href="">START CREATING</a>
        </div>

        <div class="affiliate-container1">
            <p>CREATOR</p>
        </div>
    
        <div class="affiliate-content-container1">
            <p>
                For an affordable yearly payment of ₦5,500
                start uploading and selling your own products on our platform forever as you also have people to sell it for you
            </p>
            <a class="visit-shop1" href="">START CREATING</a>
        </div>
    </main>

    
</x-guest-layout>