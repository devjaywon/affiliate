<footer class="footer">
    <div class="links">
        <div>
            <p>ALL IN ONE PLACE</p>
        </div>
        <div class="links-i">
            <a href="">FAQs</a></li>
            <a href="">How to earn</a>
            <a href="">Terms & Condition</a>
            <a href="">Privacy Policy</a>
        </div>
        
        <div class="social-media">
            <div>
                <a href=""><img src="/images/facebook.png" alt="facebook"></a>
            </div>
            <div>
                <a href=""><img src="/images/instagram.png" alt="instagram"></a>
            </div>
            <div>
                <a href=""><img src="/images/youtube.png" alt="youtube"></a>
            </div>
            <div>
                <a href=""><img src="/images/youtube.png" alt="youtube"></a>
            </div>
        </div>
    </div>
    <div class="we-footer">
        <div><p>&#169; All Rights Reserved</p></div>
        <div class="we-image">
            <div><img src="/images/IMG-20221209-WA0000.jpg" alt=""></div>
            <div><p>Wecreament Group</p></div>
        </div>
    </div>
</footer>

<footer class="footer1">
    <div class="links1">
        <div>
            <p>ALL IN ONE PLACE</p>
        </div>
        <div class="links-i1">
            <a href="">FAQs</a></li>
            <a href="">How to earn</a>
            <a href="">Terms & Condition</a>
            <a href="">Privacy Policy</a>
        </div>
        
        <div class="social-media1">
            <div>
                <a href=""><img src="/images/facebook.png" alt="facebook"></a>
            </div>
            <div>
                <a href=""><img src="/images/instagram.png" alt="instagram"></a>
            </div>
            <div>
                <a href=""><img src="/images/youtube.png" alt="youtube"></a>
            </div>
            <div>
                <a href=""><img src="/images/youtube.png" alt="youtube"></a>
            </div>
        </div>
    </div>
    <div class="we-footer1">
        <div><p>&#169; All Rights Reserved</p></div>
        <div class="we-image1">
            <div><img src="/images/IMG-20221209-WA0000.jpg" alt=""></div>
            <div><p>Wecreament Group</p></div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\aff\resources\views/layouts/_footer.blade.php ENDPATH**/ ?>