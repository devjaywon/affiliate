<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    
    
    <div style="margin:10px;padding:10px;background:#f3f5f8;">
        <a style="font-color:#fff" href="<?php echo e(route('products.create')); ?>"> Add Product </a>
    </div>
    <main class="mobile-product-container">
        <div class="we-meant-container-mobile">
            
            <p>The best value for your money all we listed here</p>
            <div></div>
        </div>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        
   
        <div class="product-home-container">
            <div class="product-container">
                        
               <img src="<?php echo e(Storage::url($product->image)); ?>"  class="product-image" height="200" alt="<?php echo e($product->name); ?>">
              <div class="product-body">
               <a href="<?php echo e(route('products.show', $product->id )); ?>"> <?php echo e($product->name); ?> </a> 
               <br>
                <?php echo e($product->description); ?> <br>
                <?php echo e($product->content); ?> <br>
            </div>
                    

                
            </div>
            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </main>

    <main>

        <div class="we-meant-container">
            <div></div>
            <p>The best value for your money all we listed here</p>
            <div></div>
        </div>

        <div class="outer-container-for-product">
            <div class="desktop-product-container">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="desktop-product-home-container">

                    <div class="product-container-d">

                        
                            <img src="<?php echo e(Storage::url($product->image)); ?>"  class="product-image" height="200" alt="<?php echo e($product->name); ?>">
                           <div class="product-body">
                            <a href="<?php echo e(route('products.show', $product->id )); ?>"> <?php echo e($product->name); ?> </a> 
                            <br>
                             <?php echo e($product->description); ?> <br>
                             <?php echo e($product->content); ?> <br>
                         </div>
                             
                    </div>
                
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           
            
            
        </div>
    </main>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\aff\resources\views/products/index.blade.php ENDPATH**/ ?>