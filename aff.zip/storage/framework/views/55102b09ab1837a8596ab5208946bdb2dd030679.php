
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form class="form" method="POST" enctype="multipart/form-data" action="<?php echo e(route('products.store')); ?>">
    	      <?php echo csrf_field(); ?>
        <p> Add Products here, Products are subjected to approval</p>

       <input type="text" id="name" placeholder="Products Name"  name="name" value="<?php echo e(old('name')); ?>" ><br>
       <input type="text" id="category" placeholder="Search categories" name="categories[]" value="<?php echo e(old('category')); ?>" required autocomplete="category" ><br>
        
        <textarea id="description" rows="3" placeholder="Enter discription"  name="description" value="<?php echo e(old('description')); ?>"></textarea><br>
       		
        <textarea id="content" rows="5" placeholder="Brief Content"  name="content" value="<?php echo e(old('content')); ?>"></textarea><br>
       
        <input type="file" id="file multiple" placeholder="Upload Images"  name="image" value="<?php echo e(old('image')); ?>" ><br>
       
        <div class="sign-up-button">
            <input type="submit" value=" <?php echo e(__('Create Product')); ?>">
          
        </div>
        
    </form>

    <form class="form1" method="POST" action="<?php echo e(route('products.store')); ?>">
        <?php echo csrf_field(); ?>
        <p> Add Products here, Products are subjected to approval</p>

        <input type="text" id="name" placeholder="Products Name"  name="name" value="<?php echo e(old('name')); ?>" ><br>
        <input type="text" id="category" placeholder="Search categories" name="categories[]" value="<?php echo e(old('category')); ?>" required autocomplete="category" ><br>
         
         <textarea id="description" rows="3" placeholder="Enter discription"  name="description" value="<?php echo e(old('description')); ?>"></textarea><br>
                
         <textarea id="content" rows="5" placeholder="Brief Content"  name="content" value="<?php echo e(old('content')); ?>"></textarea><br>
        
         <input type="file" id="file multiple" placeholder="Upload Images"  name="image" value="<?php echo e(old('image')); ?>" ><br>
         
        <div class="sign-up-button1">
            <input type="submit" value=" <?php echo e(__('Create Product')); ?>">
          
        </div>
        
    </form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\aff\resources\views/products/create.blade.php ENDPATH**/ ?>