<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="m-auto text-white text-center">
        <h1 class="text-3xl font-bold">Payment</h1>
        <form action="<?php echo e(route('pay')); ?>" method="POST" class="flex flex-col w-100 space-y-3 text-black"> 
            <?php echo csrf_field(); ?>

            <div>
                <p> You are about to subscribe for <?php echo e($plan); ?> wth a one-time payment of <?php echo e($amount); ?></p>
        
               </div>
            <input type="number" min="100" name="amount" value="<?php echo e($amount); ?>" placeholder="Amount:" required> 
            <input type="tel" name="phone" value="" placeholder="Phone Number:" required> 
            <input type="text" name="reason" value="<?php echo e($plan); ?>" placeholder="Reason:" required> 
            <select name="gateway" id="option" required>
                <option value="0">Select Payment Gateway</option>
                <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($gateway['active'] == true): ?>
                        <option value="<?php echo e($gateway['code']); ?>"><?php echo e($gateway['name']); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </select>
            <button class="btn flash-button text-white" type="submit" name="pay" id="pay" title="Pay now">Pay now</button>
        </form>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\aff\resources\views/pay/pay.blade.php ENDPATH**/ ?>