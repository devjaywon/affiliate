<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  
    <main>
        <div class="affiliate-container">
            <p>AFFILIATES</p>
        </div>
    
        <div class="affiliate-content-container">
            <p>
                An affiliate marketer is someone who promotes a product or service and earns a commission if someone buys the product or service. Affiliate marketing is a great way to make money online. It&#39;s simple and easy to do. You simply create a website or blog and promote the products or services you believe in. Then, you earn a commission on the sales you generate.
                <br><br>
                There are a few things you need to do to become an affiliate marketer. <br> <br> Firstly, you need to find a product or service you want to promote. <br> <br> Secondly, you need to find a website or blog that will accept your advertisement. <br> <br>  Finally, you need to have a marketing channel
    
                Having a marketing channel, we assure you with the system we have provided for you, we guarantee you massive success
    
                What you just need to do is to sign up as an affiliate and pay your one time commitment fee then you start promoting as we also we be supporting you in succeeding
    
                You can either sell products or you sell the subscription package, all for massive success.
            </p>
            <a class="visit-shop" href="">GET STARTED</a>
        </div>
    </main>

    <main>
        <div class="affiliate-container1">
            <p>AFFILIATES</p>
        </div>
    
        <div class="affiliate-content-container1">
            <div>
                <p>
                    An affiliate marketer is someone who promotes a product or service and earns a commission if someone buys the product or service. Affiliate marketing is a great way to make money online. It&#39;s simple and easy to do. You simply create a website or blog and promote the products or services you believe in. Then, you earn a commission on the sales you generate.
                    <br><br>
                    There are a few things you need to do to become an affiliate marketer. <br> <br> Firstly, you need to find a product or service you want to promote. <br> <br> Secondly, you need to find a website or blog that will accept your advertisement. <br> <br>  Finally, you need to have a marketing channel
        
                    Having a marketing channel, we assure you with the system we have provided for you, we guarantee you massive success
        
                    What you just need to do is to sign up as an affiliate and pay your one time commitment fee then you start promoting as we also we be supporting you in succeeding
        
                    You can either sell products or you sell the subscription package, all for massive success.
                </p>
            </div>
            
            <div>
                <a class="visit-shop1" href="">GET STARTED</a>
            </div>
            
        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?><?php /**PATH C:\xampp\aff\resources\views/pages/affiliate.blade.php ENDPATH**/ ?>