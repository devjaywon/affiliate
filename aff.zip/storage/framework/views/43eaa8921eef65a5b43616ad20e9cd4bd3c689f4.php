<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> <?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name', 'Affiliate')); ?></title>

 <link rel="stylesheet" href="<?php echo e(asset('assets/css/account.css')); ?>"> 
 <link rel="stylesheet" href="<?php echo e(asset('assets/css/withdrawal-request.css')); ?>"> 
 <link rel="shortcut icon" href="/images/IMG-20221209-WA0000.jpg" type="image/x-icon">
    <title>Affliate</title>
</head>

<body>
    <?php echo e($slot); ?>




<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\aff\resources\views/layouts/user.blade.php ENDPATH**/ ?>