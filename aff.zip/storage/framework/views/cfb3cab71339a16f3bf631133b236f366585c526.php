
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card-header"><?php echo e(__('Register')); ?></div>
    <form class="form" method="POST" action="<?php echo e(route('products.store')); ?>">
    	      <?php echo csrf_field(); ?>
        <p> Add Products here, Products are subjected to approval</p>

       <input type="text" id="lname" placeholder="Products Name" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" ><br>
       
        <textarea id="description" rows="3" placeholder="Enter discription" class="<?php $__errorArgs = ['discription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="discription" value="<?php echo e(old('description')); ?>"></textarea><br>
       		
        <textarea id="content" rows="5" placeholder="Brief Content" class="<?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="content" value="<?php echo e(old('content')); ?>"></textarea><br>
       
        <input type="file" id="file multiple" placeholder="Upload Images"  name="images[]" value="<?php echo e(old('images')); ?>" ><br>
       
        <div>
            <input type="checkbox" id="lname"><p class="agreed">I have read and agreed to the Privacy Policy and Terms & Conditions on this platform</p>
        </div>
        <div class="sign-up-button">
            <input type="submit" value=" <?php echo e(__('Create Product')); ?>">
          
        </div>
        
    </form>

    <form class="form1" action="">t
        <p>You are a step away from achieving that 7 digits income</p>
        <input type="text" id="fname" placeholder="First Name"><br>
        <input type="text" id="lname" placeholder="Middle-name"><br>
        <input type="text" id="lname" placeholder="Surname"><br>
        <input type="email" id="lname" placeholder="Email Address"><br>
        <input type="number" id="lname" placeholder="Phone Number"><br>
        <input type="password" id="lname" placeholder="Passwrord"><br>
        <input type="password" id="lname" placeholder="Confirm Password">
        <div>
            <input type="checkbox" id="lname"><p class="agreed">I have read and agreed to the Privacy Policy and Terms & Conditions on this platform</p>
        </div>
        <div class="sign-up-button1">
            <input type="button" value="Sign Up">
            <p>Already a Member</p>
            <a href="<?php echo e(route('login')); ?>">Login Instead</a>
        </div>
        
    </form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\affliate\resources\views/products/create.blade.php ENDPATH**/ ?>