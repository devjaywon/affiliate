<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <main>
        <div class="affiliate-container">
            <p>CREATOR</p>
        </div>
    
        <div class="affiliate-content-container">
            <p>
                For an affordable yearly payment of ₦5,500
                start uploading and selling your own products on our platform forever as you also have people to sell it for you
            </p>
            <a class="visit-shop" href="">START CREATING</a>
        </div>

        <div class="affiliate-container1">
            <p>CREATOR</p>
        </div>
    
        <div class="affiliate-content-container1">
            <p>
                For an affordable yearly payment of ₦5,500
                start uploading and selling your own products on our platform forever as you also have people to sell it for you
            </p>
            <a class="visit-shop1" href="">START CREATING</a>
        </div>
    </main>

    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?><?php /**PATH C:\xampp\aff\resources\views/pages/creator.blade.php ENDPATH**/ ?>