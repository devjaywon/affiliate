<?php

namespace App\Http\Controllers\Account;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

use Illuminate\Support\Facades\Config;

class MemberPackageController extends Controller
{

    public function __construct()
    {
        $user = User::find(Auth::id());
      /*  if($user->hasType())
        {
            redirect('/home');
         } */
    }


    public  function index($plan)
    {
        $amount = "5500";
        $plan == "affiliate" ? "affiliate payment" : "creator payment";
        $gateways = Config::get('paymentgateways');

        return view('pay.pay', ['amount' => $amount, 'plan' => $plan, "gateways"=> $gateways]);


    }
    public function subscribe($plan)
    {
        return view('forms.payment', $plan);
    }

}